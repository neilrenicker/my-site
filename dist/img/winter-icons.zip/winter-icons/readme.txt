Winter Icons 2012
by Neil Renicker
http://neilrenicker.com and twitter.com/neilrenicker


These are for you to have and to hold and to do with however you like under the Creative Commons Attribution 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by/3.0/

Use them in your Christmas cards, on your blooming websites, and wherever else in the world you want to. I don’t care. Attribution is appreciated but not required, and don’t sell them or act like you made them, of course. If you think of it, it would be fun if you share these, and let me know where you use them.